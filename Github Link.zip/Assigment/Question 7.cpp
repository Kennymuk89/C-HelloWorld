#include <iostream>
using namespace std;

int main(){
    int days;
    string bookType;
    double fine;

    cout<< "Enter days late: ";
    cin>> days;
    cout<< "Enter book type (regular/childrean/refernce): ";
    cin>> bookType;

    if(days <= 0) fine = 0;
    else if (bookType == "regular") fine = days* 1.5;
    else if (bookType == "children") fine = days * 1.0;
    else if (bookType == "reference") fine = days * 2.0;
    else cout << "Invalid book type!" << endl;

    cout<< "Fine: $" << fine << endl;
    return 0;
}