#include <iostream>
using namespace std;

int main(){
    double amount, discount = 0;
    cout<< "Enter purchuse amount: ";
    cin>> amount;

    if (amount > 1000) discount = 0.2;
    else if (amount > 500) discount =0.1;
    else if (amount > 100) discount = 0.05;

    double total = amount - (amount * discount);
    cout<< "Total after discount: $" << total <<endl;
    return 0;

}