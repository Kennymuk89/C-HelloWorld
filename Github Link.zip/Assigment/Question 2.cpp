#include <iostream>
using namespace std;

int main(){
    string name;
    string course;
    int score;

    cout<< "Enter student name: ";
    getline(cin, name);
    cout<< "Enter course name: ";
    getline(cin, course);
    cout<< "Enter score: ";
    cin>> score;

    cout<< "Student Name:" << name << "course: " << course << "Grade:";
    if (score >= 70) cout<< "A" << endl;
    else if (score >=60) cout<< "B" <<endl;
    else if(score >= 50) cout<< "C" <<endl;
    else if(score >= 40) cout<< "D" <<endl;
    else if(score >= 0) cout<< "F" <<endl;
    else cout << "Invalid score!" <<endl;

    return 0;
}