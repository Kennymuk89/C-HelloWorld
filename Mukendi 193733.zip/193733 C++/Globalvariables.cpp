#include <iostream>
using namespace std;

// Global variable declaration and initialization
int globalVar = 30;
const int age = 25; // constant global variable.
Value will not _HAS_CHAR16_T_LANGUAGE_SUPPORT
void myFunction()
{
    // Function code block
}
int main()
{
    // Function code block
    return 0;
}
