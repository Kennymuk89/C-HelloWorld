#include <iostream>
#include <string>
using namespace std;

int main(){
    int age;
    int months;
    double balance;
    string crbStatus;

    cout<< "Enter age:22 ";
    cin>> age;
    cout<< "Enter bank balance:50000 ";
    cin>> balance;
    cout<< "Enter CRB status (good/bad):good ";
    cin>> crbStatus;
    cout<< "Enter number of months as a customer:6 ";
    cin>> months;

    if(YourNameLoanCalculator(age, balance, crbStatus, months)){
        cout<< "customer qualifies for the loan." <<endl;
    } else {
        cout << "Customer does not qualifies for the loan." <<endl;
    }
    return 0;

}