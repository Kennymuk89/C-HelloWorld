#include <iostream>
using namespace std;

int maint(){
    // initialize and double variable
    double myNum=15.5;
    /*create a new integer variable and explicitly cast the double to int*/
    int myNewNum=int(myNum);
    //the output the new integer variable
    cout<<myNewNum2;

    return 0;
}