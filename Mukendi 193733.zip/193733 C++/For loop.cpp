#include <iostream>
using namespace std;

int main(){
int num=12;

for(int num = 12; num <= 50; num+=2){

cout<< "num=12";
cout<< ",";
}
cout<< endl;
return 0;
}


