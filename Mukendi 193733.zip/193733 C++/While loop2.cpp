#include <iostream>
using namespace std;

int main(){
    int num1=12, num2=28
    
    while(num <=28){
        cout<<"Please entre num: 12";
        cout<<"Please entre num2: 28";
        
    }
}