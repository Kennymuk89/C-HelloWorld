#include <iostream>
using namespace std;

void myFunction()
{
    // Function code block
    // Local variable declarations and initialization
    int locallVa = 30;
    const int age = 25; // constant local variable.
}
int main()
{
    // Function code block
    // Local variable declarations and initialization
    int locallVar = 30;
    const int age = 25; // constant local variable.
    return 0;
}