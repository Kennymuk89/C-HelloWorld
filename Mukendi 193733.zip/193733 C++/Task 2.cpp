#include <iostream>
using namespace std;

int main(){
    //  Variable declaration
    float costprice, sellingprice, motorvehicle,profit;
    cout<< "Enter the cost price of the motor vehicle";
    cin >> costprice;
    cout<< "Enter the selling price of the moyor vehicle";
    cin>> sellingprice;

    profit = sellingprice - costprice;
    cout<< "The profit made by the selling is" <<endl;

    return 0;



}