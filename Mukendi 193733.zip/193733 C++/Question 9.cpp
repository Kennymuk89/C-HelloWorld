#include <iostream>
using namespace std;

int main(){
    int age;
    string movieType;
    double price;

    cout<< "Enter age: ";
    cin>> age;
    cout<< "Enter movie type (regular/3D):";
    cin>> movieType;

    if (movieType == "regular") price = (age < 11|| age> 60 )? 8:10;
    else if (movieType == "3D") price = (age < 12 || age > 60) ? 12 : 15;

    cout<< "Ticket Price: $" <<price << endl;
    return 0;

}
