#include <iostream>
using namespace std;

int main(){
    int timer;
    // Swicth variable
    cout<< "Enter timer value (1-3): ";
    cin>> timer;

    swicth (timer){
        case 1: 
        cout<< "Trafic Light:Red" <<endl;
        break;
        case 2:
        cout<< "Trafic Light: Yellow" <<endl;
        break;
        case 3:
        cout<< "Trafic Light: Green" <<endl;
        break;
        default:
        cout<< "Invalid timer!" <<endl;

    }
    return 0;
}