#include <iostream>
#include <string>
using namespace std;

int main(){
    // Declare string variable
    string myFirstName, myLastName, myFullName, myFavoriteMeal, myFavoriteMovie;

    //Prompt user first name,
    cout << "myFirstName:";
    getline(cin, myFirstName);
    
    // Prompt my lastname
    cout << "myLastName:";
    getline(cin, myLastName);
    
    //Prompt my full name
    cout << "myFullName:";
    getline(cin, myFullName);
    
    //Prompt my Favorite meal
    cout << "myFavoriteMeal:";
    getline(cin, myFavoriteMeal);
    
    //Prompt my Favorite movie
    cout << "myFavoriteMeal:";
    getline(cin, myFavoriteMovie);

    cout << "Kennedy" << myFirstName << endl;
    cout << "Mukendi" << myLastName << endl;
    cout << "Kennedy Mukendi" << myFullName << endl;
    cout << "Beans and Rice" << myFavoriteMeal << endl;
    cout << "Lucky Luke" << myFavoriteMovie << endl;

    return 0;
}