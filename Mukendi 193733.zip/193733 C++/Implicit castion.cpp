#include <iostream>
using namespace std;

int main (){
    // intialize and double variable
    double myNum = 15.5;
    //create a new integer variable
    int myNewNum;
    // assign double data type to integer
    myNewNum = myNum; 
    // output the new integer variable
    cout <<myNewNum;
   
    float myNum
    // intialize and double variable
    int myNewNum;
     // assign double data type to integer
    myNewNum = myNum;
     // output the new integer variable
    cout << myNewNum;
    
    

    return 0;
}