#include <iostream>
#include <string>
using namespace std;

int main(){
    // Declare necessary variable
    string childName, interest;
    int age;

    //Prompt user for child name 
    cout<< "Please enter the child's full name: ";
    getlin(cin, childName);
    cout<< "Please enter the child's name";
    cin >> age;

    if (age >= 4 && age <= 10) 
{
    cout << "Please enter the child's interest:";
    cin >> interest;
    if (interest == "soccer") // First nested If
    {cout << childName << "has been admitted and assigned to the soccer Play group." <<endl;
    }

    if (interest == "art") // Second nested if
    {cout << childName << " has been admitted and assigned to the Art Play group." <<endl;
    }
    else
    { cout<< childName << "has been admitted and assigned to the othe group." <<endl;
    }
    else 
    { cout<< "Admission unsuccessful." << "child's age invalid" <<endl;
    }
    
return 0;
}
}

