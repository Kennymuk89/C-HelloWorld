#include <iostream>
using namespace std;

int main(){
    int num1, num2;
    cin>> num1 >> num2;

    switch (num1 > num2){
        case true: cout << "Maximum: " << num1 << endl;
        break;
        case false: cout << "Maximum: " << num2 << endl; 
        break;
    }
    return 0;

}