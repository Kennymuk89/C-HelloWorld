#include <iostream>
using namespace std;
int main(){
    cout<<"Dear BBIT Class.\n";
    cout<<"It's mid-year already!";
    return 0;
}