#include <iostream>
using namespace std;

int main(){
 float area, perimeter, base, height, hypotenuse;
 cout<< "Enter the base,heigt, and hypotenuse respectively" << endl;
 cin>> base>> height>> hypotenuse;
 area = 0.5 * height * base;
 perimeter = base + height + hypotenuse;
 cout<< "the area of the triangle is" << endl;
 cout<< "the perimeter of the triangle" << endl;

 return 0;
}
    
