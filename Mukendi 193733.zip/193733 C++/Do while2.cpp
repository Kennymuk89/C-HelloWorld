#include <iostream>
using namespace std;

int main(){
    int num=12;
    int num1=50;

    do
    {
        cout<<"Please entre num: 12";
        cout<<"Please entre num: 50";
        num+=2;
    } while(num <= 50);
    return 0;

    
}