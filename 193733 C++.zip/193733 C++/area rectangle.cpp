#include <iostream>
using namespace std;

int main(){
    // variable declaration
    int area;
    int length =8;
    int width =5;
    //comute the area
    area = length * width;
    //output area 
    cout << "Area of the rectangle is:" <<area;

return 0;
}