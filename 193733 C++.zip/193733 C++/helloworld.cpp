#include <iostream>
using namespace std;

int main() 
  { 
    cout << "hello world. this in my first C++ program";
    cout << "Strathmore University is the leading";
    cout << "University in the region!";
    
    return 0;
}