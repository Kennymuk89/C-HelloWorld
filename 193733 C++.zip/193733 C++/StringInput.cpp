#include <iostream>
#include <string>
using namespace std;

int main(){
// Declare a sting variable
string myName, description;

//Prompt user for the full name
cout << "myName: ";
getline(cin, myName);

//Prompt user for the full name
cout << "Please describe yourself: ";
getline(cin, description);

cout << "KennedyMukendi" << myName << endl;
cout << " Congolese Man:" << description << endl;

return 0;


}