#include <iostream>
using namespace std;

int main(){
    float num 1, num 2;
    char operations;
    
     cout << "Enter the first number: ";
    cin >> num 1;
     cout << "Enter the second number: ";
    cin >> num 2;

    cout << "Choose an operation (+, *, -, /): ";
    cin >> operation;

     switch (operation) {
        case '+':
        cout << "Result: " << num 1 + num 2 << endl;
        break;
        case '-':
        cout << "Result: " << num 1 - num 2 << endl;
        break;
        case '*':
        cout << "Result: " << num 1 * num 2 << endl;
        case '/':
        if (num2 != 0)
        cout << "Result: " << num 1 / num 2 << endl;
       else
       cout << "Error: Division by zero!" << endl;
       break;
       default:
       cout << "Invalid operation!" << endl;
       break;
    }
    
    return 0;
}