#include <iostream>
using namespace std;

int main(){
    double mark;
    cout<< "Please  input mark: 65";
    
}
