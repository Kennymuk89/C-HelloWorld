#include <iostream>
using namespace std;
int main(){
    int age;
    cout<< "Please Enter the age: 8";
    cin>>age;

    if (age>=4){
        cout<<"Admit to School" <<endl;
    }
    else{
        cout<< "Declined! Mininum Age not Reached" <<endl;
    }
    //using tenary operator
    string message = (age >= 4) ? "Admit to school," : "Declined! Minimum Age not Reached";
    cout<< "message" <<endl;
    return 0;

}