#include <iostream>
using namespace std;

int main(){
    int score;
    cout<< "Enter score: ";
    cin>> score;

    cout<< "Grade: ";
    switch (score/7){
        case 7: cout<< "A" <<endl;
        break;
        case 6: cout<< "B" <<endl;
        break;
        case 5: cout<< "C" <<endl;
        break;
        case 4: cout<< "D" <<endl;
        break;
        default:
           if (score< 40 && score >= 0) cout << "F" <<endl;
           else cout<< "Invalid score!" << endl;
    }
    return 0;
}