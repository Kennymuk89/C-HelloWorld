#include <iostream>
using namespace std;

int main(){
    double balance = 5000.0, amount;
    const double dailyLimit = 2000.0;

    cout<< "Enter withdrawal amount: ";
    cin >> amount;

    if (amount > balance)
    cout<< "Insufficient funds!" <<endl;
    else if (amount > dailyLimit) cout << "Amount exceeds daily limit!" << endl;
    else {
        balance -= amount;
        cout << "Withdrawal successful! Remaining balance: $" << balance << endl;
    }
    return 0;
    


}