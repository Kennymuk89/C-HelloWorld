#include <iostream>
#include <string>
using namespace std;

int main() {
    // Variables to store user inputs
    int age;
    double bank_balance;
    string crb_status;
    int months_as_customer;

    // Collecting customer details
    cout << "Enter customer's age: ";
    cin >> age;

    cout << "Enter customer's bank balance: ";
    cin >> bank_balance;

    cout << "Enter customer's CRB status (good/bad): ";
    cin >> crb_status;

    cout << "Enter the number of months the customer has been with the bank: ";
    cin >> months_as_customer;

    // Checking loan eligibility
    if (age > 22 && bank_balance > 50000 && crb_status == "good" && months_as_customer > 6) {
        cout << "The customer is qualified for the loan." << endl;
    } else {
        cout << "The customer is not qualified for the loan." << endl;
    }

    return 0;
}
