#include <iostream>
using namespace std;

int main(){
    int num =20;
    int num =0;
while (num <= 25){
    sum= sum+num;
    num ++;

}
cout<<"sum+"



}