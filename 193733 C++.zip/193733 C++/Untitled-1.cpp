#include <iostream>//Use the inputouput library
using namspace std; //Is a preprocessor directive

int main() //main function
{
    int number; //Declare variable of integer value
    cout << ''Enter a number"; //Display on the user screen 
    cin >> number; //capture input
    cout << ''you entered " + number << end1; //Display output
    cerr <<'' this is an example of an error''; //Display error messade
}