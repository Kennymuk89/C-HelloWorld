#include <iostream>
namespace std;

int main(){
    cout<<"o      o _ \n;
    cout<<"/|\\ | |\\ "\n;
    cout<<"| | |\\ "\n;
    cout<<"/\\  /\\ |_|_\\"\n;
    cout<<"                 _|______|_"\n;
    

}
