#include <iostream>
using namespace std;

int main(){
    // Variable declarations
    int num1, num2; // declare two integer variables
    bool boolVar1 = true, boolvar2 = false; // declare and initialize two bool variable
   
    // Prompt user input and capture input
    cout<< "Enter First non-zero value" << endl;
    cin>> num1;
    cout<< "Enter second non-zero value" << endl;
    cin >> num2;

    //*****Aricthmetic operators*****
    // Adition operator '+'
    cout << "sum of" << num1 << " + " << num2 << " = " << num1 + num2 << endl;
    // Subtraction operator '-'
    cout << "Diffrence of" << num1 << " - " << num2 << "=" << num1 - num2 << endl;
    // Multiplication operator '*'
    cout << "Product of" << num1 << " * " <<num2 << "=" << num1 * num2 << endl;
    //  Division operator '/'
    cout << "Division of" << num1 << " / " << num2 << "=" << num1 / num2 << endl;
    // Modulus operator '%'   
    cout << "Modulus of the two numbers: " << num1 % num2 << endl;
    // Increment '++'
    cout << "Increment" << num1 << "by 1:" << ++num1 << endl;
    // Decrement operator '--'
    cout << "Decrement" << num1 << "by 1:" << --num1 << endl;
    //****Comparison operator****
    // Greater than operator '>'
    cout << num1 << " greater than " << num2 << "=" << (bool1)(num1 > num2) << endl;
    // Less than operator '<'
    cout << num1 << " less than" << num2 << "=" << (bool1)(num1 < num2) << endl;
    // Equal to operator '='
    cout << num1 << "Equal to" << num2 << "=" << (bool1)(num1 = num2) << endl;
   // Not equal to operator '!='
   cout << num1 << " not equal to" << num2 << "=" << (bool1)(num1 != num2) << endl;

   //****BOOLEAN OPERATORS
   // Boolean operator '&&'
   cout << boolVar1 << "&&" << boolVar2 << "=" << (boolVar1 && boolVar2) << endl;
   // Boolean operator '||'
   cout << boolVar1 << "||" << boolVar2 << "=" << (boolVar1 || boolVar2) << endl;
   // Boolean operator '!'
   cout << "!" << boolVar1 << "=" << (!boolVar1) << endl;

   //***POINTER OPERATIONS */
   // Declare a pointer
   int *ptr = nullptr;
   // Output adressof num1
   cout << "Adress of num1 = " << &num1 << endl;
   // Dereference the pointer to get the value at the memory location
   cout << "Value at memory location pointed by ptr = " << *ptr << endl;


   //

   return 0;

}
