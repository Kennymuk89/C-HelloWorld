#include <iostream>
using namespace std;

int main(){
    int nums [5];
    cout<<"Please enter 5 integers: ";
    cin>> nums[0];
    cin>> nums[1];
    cin>> nums[2];
    cin>> nums [3];
    cin>> nums [4];
    cout<<"The 5 values integers entereds are: " <<endl;
    cout<<nums [0]<<endl;
    cout<<nums [1]<<endl;
    cout<<nums [2]<<endl;
    cout<<nums [3]<<endl;
    cout<<nums [4]<<endl;
    return 0;
}