#include <iostream>
using namespace std;

int main(){
    int nums[5];
    cout<< "Please enter 5 integers: ";
    for (int i=0; i< 5; i ++) {
        cin>> nums[i];
    }
    cout << "The 5 integers you entered are: " <<endl;
    for (int i = 0; i < 5; i++){
        cout << nums[i] <<endl;
    }
    return 0;
}