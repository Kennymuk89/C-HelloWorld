#include <iostream>
using namespace std;

int main(){
    int choice;
    cout<< "Menu: \n1. Area of Circle\n2. Area of Rectangle\n3. Area of Triangle\n4. Quit\nChoose an option:";
    cin>> choice;

    switch (choice){
        case 1: {
            double radius;
            cout << "Enter radius: ";
            cin>> radius;
            cout<< "Area of circle: " << 3.1415 * radius * radius <<endl;
            break;
        }
        case 3: {
            double base, height;
            cout<< "Enter base and heigth: ";
            cin>> base >> height;
            cout<< "Area of Triangle: " << 0.5 * base * height <<endl;
            break;

        }
        case 4:
        cout<< "Exiting..." <<endl;
        break;
        default:
        cout<< "Invalid choice!" <<endl;
        }
        return 0;
    
    }