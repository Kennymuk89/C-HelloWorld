#include <iostream>
using namespace sdt;

// Declare an external variable
extern int globalVar;

int main()
{
    // Acess the external variable
    cout << "In main, globalVar: " << globalVar << endl;
    
    // Modify the external variable
    globalVar = 200;
    cout << "In main after modification, globalVar" <<
    return 0;
}